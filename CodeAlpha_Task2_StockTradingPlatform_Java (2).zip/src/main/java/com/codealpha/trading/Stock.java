package com.codealpha.trading;

public class Stock {
    private final String symbol;
    private final String name;
    private double price;
    private double prevClose;
    private long volume;

    public Stock(String symbol, String name, double price) {
        this.symbol = symbol.toUpperCase();
        this.name = name;
        this.price = price;
        this.prevClose = price;
        this.volume = 0;
    }

    public String getSymbol() { return symbol; }
    public String getName() { return name; }
    public synchronized double getPrice() { return price; }
    public synchronized double getPrevClose() { return prevClose; }
    public synchronized long getVolume() { return volume; }

    public synchronized void setPrice(double newPrice) {
        this.price = Math.max(0.01, newPrice);
    }

    public synchronized void addVolume(long qty) {
        this.volume += qty;
    }

    public synchronized void nextDay() {
        this.prevClose = this.price;
        this.volume = 0;
    }

    public synchronized double pctChange() {
        if (prevClose == 0) return 0;
        return (price - prevClose) / prevClose * 100.0;
    }
}
