package com.codealpha.trading;

public class Position {
    private final String symbol;
    private int quantity;
    private double avgPrice; // weighted average

    public Position(String symbol) {
        this.symbol = symbol.toUpperCase();
        this.quantity = 0;
        this.avgPrice = 0.0;
    }

    public String getSymbol() { return symbol; }
    public int getQuantity() { return quantity; }
    public double getAvgPrice() { return avgPrice; }

    public void buy(int qty, double price) {
        double totalCost = avgPrice * quantity + price * qty;
        quantity += qty;
        avgPrice = totalCost / quantity;
    }

    public double sell(int qty, double price) {
        if (qty > quantity) throw new IllegalArgumentException("Not enough quantity");
        double realized = (price - avgPrice) * qty;
        quantity -= qty;
        if (quantity == 0) {
            avgPrice = 0.0;
        }
        return realized;
    }
}
