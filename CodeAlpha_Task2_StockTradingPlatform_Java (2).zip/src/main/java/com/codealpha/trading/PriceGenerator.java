package com.codealpha.trading;

import java.util.Random;

public class PriceGenerator {
    private final Random random = new Random();

    // Geometric random walk-ish update
    public double nextPrice(double current) {
        // drift ±0.03% per tick, volatility ~0.5% per tick
        double drift = (random.nextDouble() - 0.5) * 0.0006;
        double vol = (random.nextGaussian()) * 0.005;
        double change = 1.0 + drift + vol;
        double next = current * change;
        return Math.max(0.01, round2(next));
    }

    public static double round2(double v) {
        return Math.round(v * 100.0) / 100.0;
    }
}
