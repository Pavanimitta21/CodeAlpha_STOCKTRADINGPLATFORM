package com.codealpha.trading;

import java.nio.file.Path;
import java.util.*;

public class UserInterface {
    private final Market market = new Market();
    private final Portfolio portfolio = new Portfolio();
    private final Scanner sc = new Scanner(System.in);
    private final Persistence persistence = new Persistence(Path.of("."));

    public void run() {
        boolean running = true;
        println("===== Stock Trading Platform (Console) =====");
        while (running) {
            menu();
            String choice = prompt("Enter choice: ");
            switch (choice) {
                case "1" -> toggleTicker();
                case "2" -> showMarket();
                case "3" -> buy();
                case "4" -> sell();
                case "5" -> showPortfolio();
                case "6" -> showHistory();
                case "7" -> save();
                case "8" -> load();
                case "9" -> demoReset();
                case "0" -> { running = false; market.stopTicker(); }
                default -> println("Invalid choice.");
            }
        }
        println("Goodbye!");
    }

    private void menu() {
        println("");
        println("1) Start/Stop Market Ticker");
        println("2) View Market");
        println("3) Buy Stock");
        println("4) Sell Stock");
        println("5) Portfolio Summary");
        println("6) Transaction History");
        println("7) Save");
        println("8) Load");
        println("9) Reset Demo Data");
        println("0) Exit");
    }

    private void toggleTicker() {
        if (market.isRunning()) {
            market.stopTicker();
            println("Ticker stopped.");
        } else {
            market.startTicker();
            println("Ticker started (updates every 1s).");
        }
    }

    private void showMarket() {
        println("");
        println("SYMBOL   NAME                          PRICE    %CHG    VOLUME");
        println("------   ----------------------------  -------  ------  -------");
        for (Stock s : market.all()) {
            String row = String.format("%-7s %-28s %7.2f  %6.2f%%  %7d",
                s.getSymbol(), truncate(s.getName(), 28), s.getPrice(), s.pctChange(), s.getVolume());
            println(row);
        }
    }

    private void buy() {
        String sym = prompt("Symbol to BUY: ").toUpperCase();
        Stock s = market.get(sym);
        if (s == null) { println("Unknown symbol."); return; }
        int qty = parseInt(prompt("Quantity: "), 0);
        if (qty <= 0) { println("Invalid qty."); return; }
        boolean ok = portfolio.buy(market, sym, qty);
        if (ok) println("Bought " + qty + " " + sym + " @ " + Utils.fmt2(s.getPrice()));
        else println("Buy failed (check cash).");
    }

    private void sell() {
        String sym = prompt("Symbol to SELL: ").toUpperCase();
        Stock s = market.get(sym);
        if (s == null) { println("Unknown symbol."); return; }
        int qty = parseInt(prompt("Quantity: "), 0);
        if (qty <= 0) { println("Invalid qty."); return; }
        boolean ok = portfolio.sell(market, sym, qty);
        if (ok) println("Sold " + qty + " " + sym + " @ " + Utils.fmt2(s.getPrice()));
        else println("Sell failed (check holdings).");
    }

    private void showPortfolio() {
        double mv = portfolio.marketValue(market);
        double eq = portfolio.equity(market);
        double upnl = portfolio.unrealizedPnL(market);
        double rpnl = portfolio.realizedPnL();

        println("");
        println("CASH: " + Utils.fmt2(portfolio.getCash()));
        println("EQUITY: " + Utils.fmt2(eq) + " (Market Value " + Utils.fmt2(mv) + ")");
        println("PnL: Unrealized " + Utils.signFmt(upnl) + "  |  Realized " + Utils.signFmt(rpnl));
        println("");
        println("POSITIONS:");
        println("SYMBOL   QTY   AVG       PRICE     UPNL");
        for (Position p : portfolio.getPositions().values()) {
            Stock s = market.get(p.getSymbol());
            double up = 0.0;
            double price = 0.0;
            if (s != null) { price = s.getPrice(); up = (price - p.getAvgPrice()) * p.getQuantity(); }
            println(String.format("%-7s %-5d %-8.2f %-8.2f %8s",
                p.getSymbol(), p.getQuantity(), p.getAvgPrice(), price, Utils.signFmt(up)));
        }
    }

    private void showHistory() {
        println("");
        println("HISTORY:");
        println("TIME                 SIDE  SYMBOL  QTY   PRICE    REALIZED");
        for (Transaction t : portfolio.getHistory()) {
            println(String.format("%-19s %-4s  %-6s %-5d %-8.2f %8s",
                t.prettyTime(), t.getSide(), t.getSymbol(), t.getQuantity(), t.getPrice(), Utils.signFmt(t.getRealizedPnL())));
        }
        if (portfolio.getHistory().isEmpty()) println("(no transactions yet)");
    }

    private void save() {
        try {
            persistence.save(portfolio);
            println("Saved to data/");
        } catch (Exception e) {
            println("Save failed: " + e.getMessage());
        }
    }

    private void load() {
        try {
            persistence.load(portfolio);
            println("Loaded from data/");
        } catch (Exception e) {
            println("Load failed: " + e.getMessage());
        }
    }

    private void demoReset() {
        market.stopTicker();
        println("Resetting demo: clearing positions, cash=100000, history cleared.");
        portfolio.getPositions().clear();
        portfolio.getHistory().clear();
        portfolio.setCash(100000.0);
        for (Stock s : market.all()) s.nextDay();
    }

    private String prompt(String msg) {
        System.out.print(msg);
        return sc.nextLine().trim();
    }

    private int parseInt(String s, int def) {
        try { return Integer.parseInt(s); } catch (Exception e) { return def; }
    }

    private void println(String s) { System.out.println(s); }
    private String truncate(String s, int n) { return s.length() <= n ? s : s.substring(0, n-1) + "…"; }
}
