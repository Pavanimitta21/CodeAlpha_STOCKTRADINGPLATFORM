package com.codealpha.trading;

import java.util.*;
import java.util.concurrent.*;

public class Market {
    private final Map<String, Stock> stocks = new ConcurrentHashMap<>();
    private final PriceGenerator gen = new PriceGenerator();
    private ScheduledExecutorService scheduler;
    private ScheduledFuture<?> handle;

    public Market() {
        seed();
    }

    private void seed() {
        add(new Stock("TCS", "Tata Consultancy Services", 3925.00));
        add(new Stock("INFY", "Infosys", 1600.00));
        add(new Stock("RELI", "Reliance Industries", 2800.00));
        add(new Stock("HDFCB", "HDFC Bank", 1550.00));
        add(new Stock("WIPRO", "Wipro", 470.00));
        add(new Stock("ITC", "ITC", 450.00));
    }

    public void add(Stock s) {
        stocks.put(s.getSymbol(), s);
    }

    public Collection<Stock> all() {
        return stocks.values();
    }

    public Stock get(String symbol) {
        return stocks.get(symbol.toUpperCase());
    }

    public synchronized void startTicker() {
        if (scheduler != null) return;
        scheduler = Executors.newSingleThreadScheduledExecutor();
        handle = scheduler.scheduleAtFixedRate(() -> tick(), 0, 1, TimeUnit.SECONDS);
    }

    public synchronized void stopTicker() {
        if (handle != null) handle.cancel(true);
        if (scheduler != null) scheduler.shutdownNow();
        scheduler = null;
        handle = null;
    }

    private void tick() {
        for (Stock s : stocks.values()) {
            double next = gen.nextPrice(s.getPrice());
            s.setPrice(next);
        }
    }

    public boolean isRunning() {
        return scheduler != null;
    }
}
