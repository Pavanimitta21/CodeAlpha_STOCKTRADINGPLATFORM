package com.codealpha.trading;

public class Order {
    private final String symbol;
    private final int quantity;
    private final OrderType type;
    private final double fillPrice;
    private final long timestamp;

    public Order(String symbol, int quantity, OrderType type, double fillPrice) {
        this.symbol = symbol.toUpperCase();
        this.quantity = quantity;
        this.type = type;
        this.fillPrice = fillPrice;
        this.timestamp = System.currentTimeMillis();
    }

    public String getSymbol() { return symbol; }
    public int getQuantity() { return quantity; }
    public OrderType getType() { return type; }
    public double getFillPrice() { return fillPrice; }
    public long getTimestamp() { return timestamp; }
}
