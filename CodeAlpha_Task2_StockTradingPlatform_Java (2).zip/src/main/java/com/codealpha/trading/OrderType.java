package com.codealpha.trading;

public enum OrderType {
    BUY, SELL
}
