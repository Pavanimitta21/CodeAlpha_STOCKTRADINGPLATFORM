package com.codealpha.trading;

public class Utils {
    public static String pad(String s, int w) {
        if (s.length() >= w) return s.substring(0, w);
        return s + " ".repeat(w - s.length());
    }
    public static String fmt2(double v) {
        return String.format("%.2f", v);
    }
    public static String signFmt(double v) {
        return (v >= 0 ? "+" : "") + fmt2(v);
    }
}
