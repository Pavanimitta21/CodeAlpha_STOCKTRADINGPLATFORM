package com.codealpha.trading;

import java.util.*;

public class Portfolio {
    void setCash(double v) { this.cash = v; }
    private final Map<String, Position> positions = new HashMap<>();
    private final List<Transaction> history = new ArrayList<>();
    private double cash = 100000.0; // starting cash

    public double getCash() { return cash; }
    public Map<String, Position> getPositions() { return positions; }
    public List<Transaction> getHistory() { return history; }

    public synchronized boolean buy(Market market, String symbol, int qty) {
        Stock s = market.get(symbol);
        if (s == null) return false;
        double price = s.getPrice();
        double cost = price * qty;
        if (cost > cash) return false;
        cash -= cost;
        Position p = positions.computeIfAbsent(symbol.toUpperCase(), Position::new);
        p.buy(qty, price);
        s.addVolume(qty);
        history.add(new Transaction(new Order(symbol, qty, OrderType.BUY, price), 0.0));
        return true;
    }

    public synchronized boolean sell(Market market, String symbol, int qty) {
        Position p = positions.get(symbol.toUpperCase());
        Stock s = market.get(symbol);
        if (p == null || s == null) return false;
        if (qty > p.getQuantity()) return false;
        double price = s.getPrice();
        double realized = p.sell(qty, price);
        cash += price * qty;
        s.addVolume(qty);
        history.add(new Transaction(new Order(symbol, qty, OrderType.SELL, price), realized));
        if (p.getQuantity() == 0) positions.remove(symbol.toUpperCase());
        return true;
    }

    public synchronized double marketValue(Market market) {
        double mv = 0.0;
        for (Position p : positions.values()) {
            Stock s = market.get(p.getSymbol());
            if (s != null) mv += s.getPrice() * p.getQuantity();
        }
        return mv;
    }

    public synchronized double equity(Market market) {
        return cash + marketValue(market);
    }

    public synchronized double unrealizedPnL(Market market) {
        double upnl = 0.0;
        for (Position p : positions.values()) {
            Stock s = market.get(p.getSymbol());
            if (s != null) {
                upnl += (s.getPrice() - p.getAvgPrice()) * p.getQuantity();
            }
        }
        return upnl;
    }

    public synchronized double realizedPnL() {
        return history.stream().mapToDouble(Transaction::getRealizedPnL).sum();
    }
}
