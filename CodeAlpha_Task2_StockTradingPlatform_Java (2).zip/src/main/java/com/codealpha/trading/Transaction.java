package com.codealpha.trading;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Transaction {
    private final long time;
    private final String symbol;
    private final int quantity;
    private final double price;
    private final OrderType side;
    private final double realizedPnL; // only for sells

    public Transaction(Order order, double realizedPnL) {
        this.time = order.getTimestamp();
        this.symbol = order.getSymbol();
        this.quantity = order.getQuantity();
        this.price = order.getFillPrice();
        this.side = order.getType();
        this.realizedPnL = realizedPnL;
    }

    public long getTime() { return time; }
    public String getSymbol() { return symbol; }
    public int getQuantity() { return quantity; }
    public double getPrice() { return price; }
    public OrderType getSide() { return side; }
    public double getRealizedPnL() { return realizedPnL; }

    public String toCsv() {
        return time + "," + symbol + "," + side + "," + quantity + "," + price + "," + realizedPnL;
    }

    public static String csvHeader() {
        return "time,symbol,side,quantity,price,realizedPnL";
    }

    public String prettyTime() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(time));
    }
}
