# CodeAlpha TASK 2 – Stock Trading Platform (Console, Java 17)

A simple console-based stock trading simulator written with OOP.  
Features:
- Live mock market with ticking prices (geometric random walk)
- View market table with % change and volume
- Buy/Sell market orders
- Portfolio with positions, average price, P&L, equity, cash
- Transaction history
- Save/Load portfolio & transactions to CSV (in `data/`)
- Clean, single-file persistence (no external libs)

## Run in VS Code
1. Install the **Extension Pack for Java** and **Maven**.
2. Open this folder in VS Code.
3. Either:
   - Press **Run** on `Main.java`, or
   - In terminal:
     ```bash
     mvn -q -DskipTests compile
     mvn -q exec:java
     ```

## Menu
- 1) Start/Stop Market Ticker
- 2) View Market
- 3) Buy Stock
- 4) Sell Stock
- 5) Portfolio Summary
- 6) Transaction History
- 7) Save
- 8) Load
- 9) Reset Demo Data
- 0) Exit

Data saved under `data/` as `portfolio.csv` and `transactions.csv`.
